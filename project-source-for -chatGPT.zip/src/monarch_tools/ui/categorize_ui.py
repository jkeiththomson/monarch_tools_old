from __future__ import annotations

import curses
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from .taxonomy import Taxonomy, DEFAULT_CATEGORY, DEFAULT_GROUP
from .transactions import Txn, load_transactions, write_transactions
from .rules import load_rules, save_rules, upsert_rule_literal_description, find_rule_for_description
from .text_utils import norm_key, titleish

COLUMN_CAT = 0
COLUMN_GRP = 1

@dataclass
class UIState:
    row: int = 0
    col: int = COLUMN_CAT
    scroll: int = 0
    edit_buffer: str = ""
    edit_mode: bool = False
    digit_buffer: str = ""
    digit_ts: float = 0.0
    message: str = ""
    message_ts: float = 0.0

def run_categorize_ui(
    stdscr,
    in_csv: Path,
    rules_path: Path,
    categories_path: Path,
    groups_path: Path,
    out_csv: Optional[Path] = None,
) -> int:
    curses.curs_set(0)
    curses.use_default_colors()
    curses.start_color()
    _init_colors()

    txns, orig_cols, meta = load_transactions(in_csv)
    taxonomy = _load_taxonomy(categories_path, groups_path)
    taxonomy.normalize_display()
    taxonomy.sort_alpha()

    rules = load_rules(rules_path)

    # mark confirmed based on existing rules.json matches (literal description mapping)
    for t in txns:
        r = find_rule_for_description(rules, t.description)
        if r and norm_key(str(r.get("category",""))) == norm_key(t.category) and norm_key(str(r.get("group",""))) == norm_key(t.group):
            t.confirmed = True

    state = UIState()
    out_csv = out_csv or in_csv

    while True:
        _maybe_expire_digit_buffer(state)
        _draw(stdscr, taxonomy, txns, state)
        ch = stdscr.getch()

        if ch == curses.KEY_RESIZE:
            continue

        if ch in (ord('q'), ord('Q')):
            if _confirm_quit(stdscr, taxonomy, txns, state, rules_path, rules, categories_path, groups_path, out_csv, orig_cols, meta):
                return 0
            continue

        if _handle_nav(ch, txns, state, stdscr):
            continue

        # delete key: remove cat/grp from transaction + prune unused taxonomy entries
        if ch in (curses.KEY_DC, 127) and not state.edit_mode:
            _handle_delete(txns, taxonomy, state, categories_path, groups_path)
            _flash(state, "Cleared. (Del)")

            continue

        # backspace: edit mode deletes characters; otherwise deletes digit buffer
        if ch in (curses.KEY_BACKSPACE, 8, 127):
            if state.edit_mode:
                state.edit_buffer = state.edit_buffer[:-1]
                if not state.edit_buffer:
                    state.edit_mode = False
            else:
                state.digit_buffer = state.digit_buffer[:-1]
                state.digit_ts = time.time()
            continue

        # digits: CatID buffer and highlight
        if not state.edit_mode and 48 <= ch <= 57:
            digit = chr(ch)
            _push_digit(state, digit)
            # if we have 3 digits, try apply cat id immediately? (we still require Enter to approve)
            continue

        # letters: start/continue edit
        if 65 <= ch <= 90 or 97 <= ch <= 122 or ch == ord(' ') or ch == ord('-') or ch == ord('&'):
            c = chr(ch)
            if not state.edit_mode:
                state.edit_mode = True
                state.edit_buffer = ""
            state.edit_buffer += c
            continue

        # Enter: assign/approve (ONLY Enter approves, per A)
        if ch in (curses.KEY_ENTER, 10, 13):
            _handle_enter(taxonomy, txns, state, rules)
            # if all confirmed, show SAVE button and allow 's'
            if _all_confirmed(txns):
                _flash(state, "All confirmed — press S to SAVE.")
            continue

        # Save (only when all confirmed): 's' or 'S'
        if ch in (ord('s'), ord('S')) and _all_confirmed(txns):
            _save_all(taxonomy, txns, state, rules_path, rules, categories_path, groups_path, out_csv, orig_cols, meta)
            return 0

def _init_colors():
    # pair ids
    curses.init_pair(1, curses.COLOR_GREEN, -1)   # confirmed
    curses.init_pair(2, curses.COLOR_YELLOW, -1)  # pending
    curses.init_pair(3, curses.COLOR_RED, -1)     # invalid
    curses.init_pair(4, curses.COLOR_CYAN, -1)    # headers
    curses.init_pair(5, curses.COLOR_WHITE, curses.COLOR_GREEN)  # highlight per spec (white on dark green-ish)
    curses.init_pair(6, curses.COLOR_BLACK, curses.COLOR_WHITE)  # focus: black on very light bg  # focus cell (high contrast)
    curses.init_pair(7, curses.COLOR_WHITE, -1)   # normal
    curses.init_pair(8, curses.COLOR_MAGENTA, -1) # messages

    curses.init_pair(9, curses.COLOR_BLACK, curses.COLOR_WHITE)  # panel text (high contrast)
def _color_for_txn(t: Txn) -> int:
    if t.confirmed and _is_legit(t):
        return curses.color_pair(1)
    if _is_legit(t):
        return curses.color_pair(2)
    return curses.color_pair(3)

def _is_legit(t: Txn) -> bool:
    return norm_key(t.category) != norm_key(DEFAULT_CATEGORY) and norm_key(t.group) != norm_key(DEFAULT_GROUP)


def _move_category_to_group(taxonomy: Taxonomy, category: str, old_group: str, new_group: str) -> None:
    """Move a category between groups in the in-memory taxonomy.

    This fixes the common case where the user mistypes a group (e.g. 'Finkface') and later corrects it.
    We want the category to end up under the corrected group, not remain attached to the old one.
    """
    cat = titleish(category).strip()
    if not cat:
        return
    og = (old_group or "").strip()
    ng = titleish(new_group).strip()
    if not ng:
        return

    # Ensure destination group exists
    if norm_key(ng) not in [norm_key(g.rstrip(':').strip()) for g in taxonomy.groups]:
        taxonomy.add_group(ng)

    # Normalize group keys in internal mappings
    # taxonomy.group_to_cats is expected to be: {group_name: [categories...]}
    g2c = getattr(taxonomy, "group_to_cats", None)
    if not isinstance(g2c, dict):
        # Fall back to add_category behavior
        taxonomy.add_category(cat, ng)
        return

    def _canon_group(name: str) -> str:
        for g in taxonomy.groups:
            if norm_key(g.rstrip(':').strip()) == norm_key(name.rstrip(':').strip()):
                return g.rstrip(':').strip()
        return titleish(name.rstrip(':').strip())

    ogc = _canon_group(og) if og else ""
    ngc = _canon_group(ng)

    # Remove from old group list (if present)
    if ogc and ogc in g2c:
        g2c[ogc] = [c for c in g2c.get(ogc, []) if norm_key(c) != norm_key(cat)]
        # If old group is now empty, drop it (unless it's the DEFAULT_GROUP)
        if not g2c[ogc] and norm_key(ogc) != norm_key(DEFAULT_GROUP):
            g2c.pop(ogc, None)
            taxonomy.groups = [g for g in taxonomy.groups if norm_key(g.rstrip(':').strip()) != norm_key(ogc)]

    # Add to new group if missing
    lst = g2c.get(ngc, [])
    if not any(norm_key(c) == norm_key(cat) for c in lst):
        lst.append(cat)
    g2c[ngc] = lst
def _all_confirmed(txns: List[Txn]) -> bool:
    for t in txns:
        if not (t.confirmed and _is_legit(t)):
            return False
    return True

def _flash(state: UIState, msg: str, seconds: float = 1.2):
    state.message = msg
    state.message_ts = time.time() + seconds

def _maybe_expire_digit_buffer(state: UIState, timeout: float = 1.2):
    if state.digit_buffer and (time.time() - state.digit_ts) > timeout:
        state.digit_buffer = ""

def _push_digit(state: UIState, digit: str):
    now = time.time()
    if state.digit_buffer and (now - state.digit_ts) > 1.2:
        state.digit_buffer = ""
    if len(state.digit_buffer) >= 3:
        state.digit_buffer = ""
    state.digit_buffer += digit
    state.digit_ts = now

def _handle_nav(ch: int, txns: List[Txn], state: UIState, stdscr) -> bool:
    max_row = len(txns) - 1
    if ch == curses.KEY_UP:
        state.row = max(0, state.row - 1)
        state.edit_mode = False
        state.edit_buffer = ""
        return True
    if ch == curses.KEY_DOWN:
        state.row = min(max_row, state.row + 1)
        state.edit_mode = False
        state.edit_buffer = ""
        return True
    if ch == curses.KEY_LEFT:
        state.col = COLUMN_CAT
        state.edit_mode = False
        state.edit_buffer = ""
        return True
    if ch == curses.KEY_RIGHT:
        state.col = COLUMN_GRP
        state.edit_mode = False
        state.edit_buffer = ""
        return True
    return False

def _handle_enter(taxonomy: Taxonomy, txns: List[Txn], state: UIState, rules) -> None:
    t = txns[state.row]
    cat_items = taxonomy.compute_cat_ids()

    # 1) digit buffer takes precedence
    if state.digit_buffer:
        try:
            wanted = int(state.digit_buffer)
        except ValueError:
            wanted = -1
        match = next((x for x in cat_items if x[0] == wanted), None)
        if match:
            _, cat, grp = match
            if state.col == COLUMN_CAT:
                base_attr = curses.color_pair(6) | curses.A_BOLD
                if state.edit_mode:
                    buf = state.edit_buffer

                    # Paint background for the whole cell, then layer typed text + ghost suffix.
                    stdscr.addstr(y, cat_field_start, " " * col_cat_w, base_attr)
                    stdscr.addstr(y, cat_field_start, buf[:col_cat_w], base_attr)

                    ghost = _ghost_completion_category(taxonomy, buf)
                    if ghost and ghost.lower().startswith(buf.lower()) and len(ghost) > len(buf):
                        suffix = ghost[len(buf):]
                        x = cat_field_start + min(len(buf), col_cat_w)
                        max_suffix = max(0, col_cat_w - min(len(buf), col_cat_w))
                        if max_suffix > 0:
                            stdscr.addstr(y, x, suffix[:max_suffix], base_attr | curses.A_DIM)
                else:
                    stdscr.addstr(y, cat_field_start, _pad(str(t.category), col_cat_w), base_attr)
            else:
                base_attr = curses.color_pair(6) | curses.A_BOLD
                if state.edit_mode:
                    buf = state.edit_buffer
                    stdscr.addstr(y, grp_field_start, " " * col_grp_w, base_attr)
                    stdscr.addstr(y, grp_field_start, buf[:col_grp_w], base_attr)

                    ghost = _ghost_completion_group(taxonomy, buf)
                    if ghost and ghost.lower().startswith(buf.lower()) and len(ghost) > len(buf):
                        suffix = ghost[len(buf):]
                        x = grp_field_start + min(len(buf), col_grp_w)
                        max_suffix = max(0, col_grp_w - min(len(buf), col_grp_w))
                        if max_suffix > 0:
                            stdscr.addstr(y, x, suffix[:max_suffix], base_attr | curses.A_DIM)
                else:
                    stdscr.addstr(y, grp_field_start, _pad(str(t.group), col_grp_w), base_attr)
        else:
            stdscr.addstr(y, 0, line.ljust(list_w-1), color)

    # Help panel
    hx = list_w + 1
    stdscr.addstr(y0+2, hx, "Keys", curses.color_pair(4))
    help_lines = [
        "0-9    cat id",
        "Enter  approve/assign",
        "a-z    type name",
        "Del    clear cat/grp",
        "Bksp   undo keystroke",
        "q      quit",
    ]
    for i, ln in enumerate(help_lines):
        if y0+3+i < h:
            stdscr.addstr(y0+3+i, hx, ln[:help_w-1].ljust(help_w-1), curses.color_pair(9) | curses.A_BOLD)

    # Footer message / SAVE button
    footer_y = h - 1
    if _all_confirmed(txns):
        btn = "   [  SAVE  ]   (press S)   "
        x = max(0, (w - len(btn)) // 2)
        stdscr.addstr(footer_y, 0, " " * (w-1))
        stdscr.addstr(footer_y, x, btn[:w-1], curses.A_BOLD | curses.color_pair(5))
    else:
        msg = ""
        if state.message and time.time() < state.message_ts:
            msg = state.message
        elif state.digit_buffer:
            msg = f"CatID: {state.digit_buffer}"
        elif state.edit_mode:
            msg = f"Typing: {state.edit_buffer}"
        stdscr.addstr(footer_y, 0, msg[:w-1].ljust(w-1), curses.A_DIM)

    stdscr.refresh()

def _ghost_completion_category(taxonomy: Taxonomy, typed: str) -> str:
    typed = typed or ""
    typedk = norm_key(typed)
    if not typedk:
        return typed
    # best prefix match
    best = None
    for _, cat, _ in taxonomy.compute_cat_ids():
        if norm_key(cat).startswith(typedk):
            best = cat
            break
    if best:
        return titleish(best)
    return titleish(typed)

def _ghost_completion_group(taxonomy: Taxonomy, typed: str) -> str:
    typed = typed or ""
    typedk = norm_key(typed)
    if not typedk:
        return typed
    for g in taxonomy.groups:
        if norm_key(g).startswith(typedk):
            return g
    return titleish(typed)
