from __future__ import annotations

def cmd_hello(argv: list[str] | None = None) -> int:
    print("Hello, MoFo!")
    return 0
